def fun(i):
    print("hello",i)
j=10
fun(j)

def fun(i):
    print("hello",i)

fun(5+2*3)

def fun(i):
    print("hello",i)

fun(5)

def fun(i):
    print("hello",i)

fun(5)