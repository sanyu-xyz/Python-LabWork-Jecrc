import math
x=int(input("enter value of x : "))
y=int(input("enter value of y : "))
print(pow(x,y))
