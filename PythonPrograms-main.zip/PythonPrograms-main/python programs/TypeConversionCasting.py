# TYPE CONVERSION
a=2
b=2.5
sum=a+b
print(sum)

# a="2"            give error as we 
# b=2.5                cant add string and float
# print(a+b)

#  TYPE CAST

a=int("2")          #typecast in int
b=2.5
print(a+b)


a=float("2")        #typecast in float
b=2.5
print(a+b)

a="2"
b=str(5.5)          #typecast in string
print(a+b)



a="krishna"
b=str(5.5)          #typecast in string
print(a+b)
