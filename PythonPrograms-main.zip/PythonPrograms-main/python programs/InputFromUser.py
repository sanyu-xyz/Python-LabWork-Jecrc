name= input("Enter your name: ")
print("welcome",name)
age= input("Enter your age: ")
print("Your age is",age)
marks= input("Enter your marks: ")
print("Your marks is",marks)



val=input("enter value")    #we always get input in foirm of string
print(type(val),val)

val=int(input("enter value"))  #type cast input in integer
print(type(val),val)
