
#input two number and  print sum
a=int(input("enter a"))   
b=int(input("enter b"))   
sum=a+b
print(sum)


#input side of square and print area
side=int(input("enter side of square"))
area=side*side
print("area of square=",area)

#input two floating number and print average
x=float(input("enter x:"))
y=float(input("enter y:"))
sum=x+y
avg=sum/2
print("average=",avg)

#Wap to input 2 integer numbers a and b
#   Print true if a is greater than or equals to b.if  not print false
a=int(input("enter a"))   
b=int(input("enter b"))   
print(a>=b)
