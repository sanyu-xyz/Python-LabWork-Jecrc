for i in range(5):           
    pass
print("show use of pass")

"""
for i in range(5):           
    if we put this place empty then it shows an erroe hence we hjave to use pass statement
print("show use of pass")
""" 