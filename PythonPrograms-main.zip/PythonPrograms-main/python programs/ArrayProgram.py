# using python array module
from array import array
a=array('i',[1,2,3,4,5])
print(a)
print(a[0])

# # using numpy library
# import numpy as np
# a=np.array([1,2,3,4,5])
# print(a)
# print(a[0])

# using python array module 2d array
from array import array
a=([1,2,3,4,5],[6,7,8,9,0])
print(a)
# print(a[0][4])

