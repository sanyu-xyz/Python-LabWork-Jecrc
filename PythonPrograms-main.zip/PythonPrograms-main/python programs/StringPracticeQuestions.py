# WAP to input user's first name and print its length\
name=input("enter your first name ")
print("lenth of your name is :",len(name))

#WAP to find the occurence of '$'in  a given string 
str="hi, $I am the $ sign $"
print(str.count("$"))
