a=5
b=10
sum=a+b
print("sum=",sum)  #sum
difference1=b-a
difference2=a-b


"""
 another way to write multi line comment

 """
print("b-a=",difference1)
print("a-b=",difference2)