# print("hello World")
# print("my name is krishna")
# print("my age is 21")
# print("we can also print two statements together using comma","statement ","through this way  we can print more than one statements in same line")
# print(20)
# print(21)
# print(20+21)



