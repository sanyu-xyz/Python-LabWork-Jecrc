name="Krishna"
age=21
place="jaipur"
age2=age
print("name")
print(name)
print(age)
print(place)
print("my name is:",name)
print("my age is:",age2)