age=14
if(age>=18):
    print("can vote")
    print("can drive")
else:
    print("neither vote nor drive")

light="green"
if(light=="red"):
    print("stop")
elif(light=="green"):
    print("go")
elif(light=="yellow"):
    print("wait")   

num1=5
if(num1>2):
    print("greator than 2")     #when use if both condition get checked
if(num1>3):
    print("greator than 3")

num2=5
if(num2>2):
    print("greator than 2") #when using elif since first coindition is true hence elif condition not get checked
elif(num2>3):
    print("greator than 3")

