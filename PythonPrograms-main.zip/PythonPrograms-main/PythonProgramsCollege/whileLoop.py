# # Enteredpassword=int(input("Enter password: "))
# Enteredpassword=input("Enter password: ")
# orgPassword="krishna_1234"
# while(Enteredpassword!=orgPassword):
#     print("enter correct password")
#     # Enteredpassword=int(input("Enter password again : "))
#     Enteredpassword=input("Enter password again : ")
# if(Enteredpassword==orgPassword):
#     print("success")

