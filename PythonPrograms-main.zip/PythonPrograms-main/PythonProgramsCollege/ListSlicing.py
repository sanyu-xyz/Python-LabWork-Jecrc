# list=["sharad","ansh","mohit","rohan","krishna","abin","kunal"]
# print(list[2:4])
# # print(list[ : ])
# # print(list[2 : ])
# # print(list[ :5 ])
# print(list[-1])
# print(list[-2])

# print(list[-4:-2])
# print(list[1:-3])
# print(list[1:])
# print(list[-3:-1])
# print(list[ ::-1])
# print(list[1 :: -1])
# print(list[-3::-1])
# print(list[1::-2])
# print(list[1::-3])
# print(list[5: :-3])
# print(list[5:3 :-3])
# print(list[5:-3 :-3])



# list=["sharad","ansh","mohit","rohan","krishna","abin","kunal"]
# print(list[-1:-4])
# print(list[4:1])
# print(list[5:-1 :-3])
# print(list[5:-1 :3])
# print(list[1:-1 :3])

list=[10,"Aman","3.14","Rohan",True,"Rohit","Mark"]
print(list[:3])
print(list[2:5:1])
print(list[-3:-5])
print(list[-2])
print(list[::])
print(list[::-1])


