# list=[5, 20.5,"hello"]
# print(list)

# #nested list
# list=[["mohan",1965],["ravi",1920],["rishi",1996]]
# print(list)

# #Acessing elements
# list=[1]
# list=[0]
# list=[5]


# #List Operations

# #list Concatenation, using +

# list1=[1,3,5,7,9]
# list2=[2,4,6,8,10]
# print(list1 + list2)
# print(list2 + list1)

# list1=["apple","orange","guvava"]
# list2=["tomato","potato","cucumber"]
# print(list1+list2)
# print(list2+list1)

#list repetation using *
list1=["hello"]
print(list1 *3)

list2=("tomato","potato","cucumber")
print(list2 *3)

list3=[1,3,5,7,9]
print(list3*3)

#membership operator

list1=["tomato","potato","cucumber"]
print( "cucumber" in list1 )
print( "brinjal" in list1 )


