#increment
# for n in range(5):
#     print(n)
# for n in range(1,5):
#     print(n)
# for n in range(1,10,2):
#     print(n)
# for n in range(10,1,-2):
#     print(n)

# #Wap using for loop to print all  numbers from m to n ,thjereby clarify them as even or odd 

# m=int(input("enter first value"))
# n=int(input("enter second value"))

# if (n>m):
    
#     for num in range(m,n):

#         if(num%2==0):
#             print("even")
#         else:
#             print("odd") 
# else:
#     for num in range(n,m):

#         if(num%2==0):
#             print("even")
#         else:
#             print("odd") 

# m=int(input("enter smaller value"))
# n=int(input("enter greator value"))

# for num in range(m,n):

#     if(num%2==0):
#         print("even")
#     else:
#         print("odd") 


# #decrement
# for n in range(10,0,-1):
#     print(n)
# print("done")
# for n in range(10,0,-2):
#     print(n)
# print("done")
# for n in range(10,4,-2):
#     print(n)
# print("done")
# for n in range(10,2):  #run nmhi hoga
#     print(n)




