# #Prime  number 
# num=int(input("enter  a number: "))
# flag=True

# if(num<2):
#     flag=False
# else:
#     for n in range(2,num):
#         if(num % n==0):
#              flag=False
#              break  #break is used to make code more optimize as when once condition get false ,loop cannot execute further 


# if(flag==True):
#     print("prime number")
# else:
#     print("number is composite")

#
