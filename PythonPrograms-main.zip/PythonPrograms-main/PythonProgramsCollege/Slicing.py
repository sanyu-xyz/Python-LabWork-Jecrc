str="hello python"
print(str[0])
print(str[0:7])
print(str[1:4])
print(str[ :3])
print(str[1:])

print(str[-1])
print(str[-4])
print(str[-4: ])
print(str[-4:-1])
print(str[ :-4])

print(str[ ::-1]) # letter chod chod ke print karane ke loiye use karte hai  :: ka
print(str[ ::-2])
print(str[2 ::])
print(str[ ::2 ])